import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go

def show_model_performance(model, X_test, y_test, feature_names):
    """
    Display model performance metrics, confusion matrix, and feature importance
    """
    # Get model performance metrics
    performance_metrics, conf_matrix, feature_imp = get_model_performance_data(model, X_test, y_test, feature_names)
    
    # Create tabs for different performance aspects
    tab1, tab2, tab3 = st.tabs(["Performance Metrics", "Confusion Matrix", "Feature Importance"])
    
    with tab1:
        show_performance_metrics(performance_metrics)
    
    with tab2:
        show_confusion_matrix(conf_matrix)
    
    with tab3:
        show_feature_importance(feature_imp, feature_names)

def get_model_performance_data(model, X_test, y_test, feature_names):
    """
    Calculate performance metrics, confusion matrix, and feature importance
    """
    # Make predictions
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    
    # Calculate metrics
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
    
    metrics = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1': f1_score(y_test, y_pred),
        'roc_auc': roc_auc_score(y_test, y_prob)
    }
    
    # Confusion matrix
    conf_matrix = confusion_matrix(y_test, y_pred)
    
    # Feature importance
    feature_importance = model.feature_importances_
    
    return metrics, conf_matrix, feature_importance

def show_performance_metrics(metrics):
    """
    Display performance metrics as a table and gauge charts
    """
    st.subheader("Model Performance Metrics")
    
    # Display metrics as a table
    metrics_df = pd.DataFrame({
        'Metric': ['Accuracy', 'Precision', 'Recall', 'F1 Score', 'ROC AUC'],
        'Value': [
            metrics['accuracy'],
            metrics['precision'],
            metrics['recall'],
            metrics['f1'],
            metrics['roc_auc']
        ]
    })
    
    st.dataframe(metrics_df.style.format({'Value': '{:.2%}'}), use_container_width=True)
    
    # Create gauge charts for metrics
    col1, col2, col3 = st.columns(3)
    
    # Accuracy gauge
    with col1:
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = metrics['accuracy'] * 100,
            title = {'text': "Accuracy"},
            gauge = {
                'axis': {'range': [0, 100]},
                'bar': {'color': "#FF69B4"},
                'steps': [
                    {'range': [0, 60], 'color': "lightgray"},
                    {'range': [60, 80], 'color': "lightpink"},
                    {'range': [80, 90], 'color': "pink"},
                    {'range': [90, 100], 'color': "hotpink"}
                ]
            },
            number = {'suffix': "%", 'valueformat': ".1f"}
        ))
        st.plotly_chart(fig, use_container_width=True)
    
    # Precision gauge
    with col2:
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = metrics['precision'] * 100,
            title = {'text': "Precision"},
            gauge = {
                'axis': {'range': [0, 100]},
                'bar': {'color': "#FF69B4"},
                'steps': [
                    {'range': [0, 60], 'color': "lightgray"},
                    {'range': [60, 80], 'color': "lightpink"},
                    {'range': [80, 90], 'color': "pink"},
                    {'range': [90, 100], 'color': "hotpink"}
                ]
            },
            number = {'suffix': "%", 'valueformat': ".1f"}
        ))
        st.plotly_chart(fig, use_container_width=True)
    
    # Recall gauge
    with col3:
        fig = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = metrics['recall'] * 100,
            title = {'text': "Recall"},
            gauge = {
                'axis': {'range': [0, 100]},
                'bar': {'color': "#FF69B4"},
                'steps': [
                    {'range': [0, 60], 'color': "lightgray"},
                    {'range': [60, 80], 'color': "lightpink"},
                    {'range': [80, 90], 'color': "pink"},
                    {'range': [90, 100], 'color': "hotpink"}
                ]
            },
            number = {'suffix': "%", 'valueformat': ".1f"}
        ))
        st.plotly_chart(fig, use_container_width=True)
    
    # Add explanation for metrics
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.markdown("""
    ### Understanding the Metrics
    
    - **Accuracy**: Percentage of correctly classified instances.
    - **Precision**: Percentage of positive (malignant) predictions that were correct.
    - **Recall**: Percentage of actual positive (malignant) cases that were correctly identified.
    - **F1 Score**: Harmonic mean of precision and recall.
    - **ROC AUC**: Area under the ROC curve, measuring the model's ability to discriminate between classes.
    """)
    st.markdown('</div>', unsafe_allow_html=True)

def show_confusion_matrix(conf_matrix):
    """
    Display and explain the confusion matrix
    """
    st.subheader("Confusion Matrix")
    
    # Create confusion matrix dataframe
    conf_matrix_df = pd.DataFrame(conf_matrix, 
                                columns=['Predicted Benign', 'Predicted Malignant'],
                                index=['Actual Benign', 'Actual Malignant'])
    
    # Display the matrix
    col1, col2 = st.columns([3, 2])
    
    with col1:
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.heatmap(conf_matrix_df, annot=True, fmt='d', cmap='PiYG', ax=ax)
        st.pyplot(fig)
    
    with col2:
        st.markdown("""
        ### Interpreting the Confusion Matrix
        
        - **True Negatives (TN)**: Correctly predicted benign cases
        - **False Positives (FP)**: Benign cases incorrectly predicted as malignant
        - **False Negatives (FN)**: Malignant cases incorrectly predicted as benign
        - **True Positives (TP)**: Correctly predicted malignant cases
        
        ### Implications
        
        In medical diagnostics, the cost of false negatives (missing a cancer diagnosis) is typically higher than 
        false positives. Our model achieves a good balance between sensitivity (recall) and specificity.
        """)

def show_feature_importance(feature_imp, feature_names):
    """
    Display and explain feature importance
    """
    st.subheader("Feature Importance")
    
    # Create a DataFrame with feature importance
    feature_imp_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': feature_imp
    }).sort_values('Importance', ascending=False)
    
    # Plot feature importance
    fig = px.bar(feature_imp_df, 
                x='Importance', 
                y='Feature',
                orientation='h',
                title='Feature Importance for Breast Cancer Prediction',
                color='Importance',
                color_continuous_scale=px.colors.sequential.Purp)
    
    fig.update_layout(yaxis={'categoryorder': 'total ascending'})
    st.plotly_chart(fig, use_container_width=True)
    
    # Add explanation for feature importance
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.markdown("""
    ### Understanding Feature Importance
    
    The chart shows which features are most influential in the model's predictions. Higher values indicate features that have a greater impact on the classification decision.
    
    ### Limitations
    
    - Feature importance doesn't indicate whether a feature increases or decreases the likelihood of cancer
    - Feature importance doesn't capture interaction effects between features
    - Feature importance doesn't indicate the direction of influence (positive or negative)
    
    ### Key Findings
    
    Based on the feature importance chart, we can identify which cell characteristics are most predictive of malignancy.
    """)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Top 5 features
    top5_idx = feature_imp.argsort()[-5:]
    top5_features = [feature_names[i] for i in top5_idx]
    top5_importance = feature_imp[top5_idx]
    
    st.success(f"""
    **Top 5 Most Important Features:**
    1. {top5_features[4]} (Importance: {top5_importance[4]:.4f})
    2. {top5_features[3]} (Importance: {top5_importance[3]:.4f})
    3. {top5_features[2]} (Importance: {top5_importance[2]:.4f})
    4. {top5_features[1]} (Importance: {top5_importance[1]:.4f})
    5. {top5_features[0]} (Importance: {top5_importance[0]:.4f})
    """)