import streamlit as st

def show_awareness_page():
    st.markdown("<h1 class='pink-header' style='text-align: center; color: #FF69B4;'>Breast Cancer Awareness</h1>", unsafe_allow_html=True)
    
    # Center the ribbon image
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.image("assets/pink_ribbon.svg", width=180)
    
    # Add information about breast cancer awareness
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.subheader("What is Breast Cancer?")
    st.markdown("""
    Breast cancer is a disease in which cells in the breast grow out of control. There are different kinds of breast cancer, 
    depending on which cells in the breast turn into cancer. Breast cancer can begin in different parts of the breast. 
    
    The breast is made up of three main parts:
    - Lobules: The glands that produce milk
    - Ducts: The tubes that carry milk to the nipple
    - Connective tissue: The fatty tissue and ligaments surrounding the ducts and lobules
    
    Most breast cancers begin in the ducts or lobules. It can spread outside the breast through blood and lymph vessels 
    to other parts of the body.
    """)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Add information about signs and symptoms
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.subheader("Signs and Symptoms")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### Common symptoms include:
        
        - New lump in the breast or underarm (armpit)
        - Thickening or swelling of part of the breast
        - Irritation or dimpling of breast skin
        - Redness or flaky skin in the nipple area or the breast
        - Pulling in of the nipple or pain in the nipple area
        - Nipple discharge other than breast milk, including blood
        - Any change in the size or the shape of the breast
        - Pain in any area of the breast
        """)
    
    with col2:
        st.info("""
        Remember that these symptoms can happen with other conditions that are not cancer. If you have any signs or symptoms
        that worry you, be sure to see your doctor right away.
        """)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # What to do if you suspect breast cancer
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.subheader("What to Do If You Suspect Breast Cancer")
    
    st.markdown("""
    ### 1. See a healthcare provider
    
    If you notice any changes in your breast, schedule an appointment with your healthcare provider for a clinical breast exam.
    They can evaluate your symptoms and determine if you need additional testing.
    
    ### 2. Get appropriate screening
    
    Depending on your age and risk factors, your doctor may recommend:
    - **Mammogram**: An X-ray of the breast
    - **Ultrasound**: Uses sound waves to produce images of the breast
    - **MRI**: Magnetic resonance imaging for detailed images of breast tissue
    - **Biopsy**: Removal of a small amount of tissue for examination under a microscope
    
    ### 3. Know your risk factors
    
    Certain factors can increase your risk of breast cancer:
    - Being female
    - Increasing age
    - Personal or family history of breast cancer
    - Inherited genes that increase cancer risk (BRCA1 and BRCA2)
    - Radiation exposure
    - Obesity
    - Beginning your period before age 12
    - Starting menopause at an older age
    - Having your first child at an older age
    - Postmenopausal hormone therapy
    
    ### 4. Regular screening
    
    The American Cancer Society recommends:
    - Women ages 40 to 44: Have the option to start annual breast cancer screening with mammograms
    - Women ages 45 to 54: Should get mammograms every year
    - Women 55 and older: Can switch to mammograms every 2 years, or continue yearly screening
    """)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Resources
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.subheader("Resources and Support")
    
    st.markdown("""
    ### Organizations
    
    - **[American Cancer Society](https://www.cancer.org/)**: Information, programs, services, and support for people with cancer and their families.
    - **[National Breast Cancer Foundation](https://www.nationalbreastcancer.org/)**: Provides education, support, and early detection services.
    - **[Breast Cancer Research Foundation](https://www.bcrf.org/)**: Funds research to prevent and cure breast cancer.
    - **[Susan G. Komen](https://www.komen.org/)**: Supports breast cancer research, education, advocacy, health services, and social support programs.
    
    ### Support Hotlines
    
    - **National Cancer Institute**: 1-800-4-CANCER (1-800-422-6237)
    - **American Cancer Society**: 1-800-ACS-2345 (1-800-227-2345)
    
    ### Remember
    
    Early detection is critical for successful treatment of breast cancer. Regular self-exams, clinical breast exams, and 
    mammograms are important tools for early detection.
    """)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Add a disclaimer
    st.warning("""
    **Disclaimer**: This dashboard is for educational and informational purposes only and is not intended to replace professional 
    medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health providers with 
    any questions you may have regarding a medical condition.
    """)