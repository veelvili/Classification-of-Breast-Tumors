import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

def load_data(file_path):
    """
    Load and prepare the breast cancer dataset.
    
    Parameters:
    file_path (str): Path to the CSV file
    
    Returns:
    pd.DataFrame: The loaded and prepared dataset
    """
    # Load the data
    data = pd.read_csv(file_path)
    
    # Check for missing values
    data.dropna(inplace=True)
    
    return data

def preprocess_data(data):
    """
    Preprocess the breast cancer data for model training.
    
    Parameters:
    data (pd.DataFrame): The breast cancer dataset
    
    Returns:
    tuple: (X, y, feature_names) - preprocessed features, target, and feature names
    """
    # Drop the id column
    if 'id' in data.columns:
        data = data.drop('id', axis=1)
    
    # Convert diagnosis to binary (M=1, B=0)
    data['diagnosis'] = data['diagnosis'].map({'M': 1, 'B': 0})
    
    # Separate features and target
    X = data.drop('diagnosis', axis=1)
    y = data['diagnosis']
    
    # Save feature names
    feature_names = X.columns.tolist()
    
    # Scale the features
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    return X, y, feature_names

def create_feature_input(data, features):
    """
    Create input fields for features with min, max values from the dataset.
    
    Parameters:
    data (pd.DataFrame): The dataset
    features (list): List of feature names to create inputs for
    
    Returns:
    dict: Dictionary of feature values entered by the user
    """
    feature_inputs = {}
    
    for feature in features:
        if feature in data.columns:
            min_val = float(data[feature].min())
            max_val = float(data[feature].max())
            mean_val = float(data[feature].mean())
            
            # Create a slider for the feature
            feature_inputs[feature] = st.slider(
                f"{feature}",
                min_value=min_val,
                max_value=max_val,
                value=mean_val,
                step=(max_val - min_val) / 100,
                format="%.4f"
            )
    
    return feature_inputs
