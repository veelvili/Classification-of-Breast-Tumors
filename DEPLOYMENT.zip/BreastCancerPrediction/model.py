import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    roc_auc_score, confusion_matrix
)
from imblearn.over_sampling import SMOTE

def train_model(X, y, test_size=0.25, random_state=42):
    """
    Train a Random Forest model on the breast cancer data.
    
    Parameters:
    X (np.array): Feature matrix
    y (np.array): Target vector
    test_size (float): Proportion of data to use for testing
    random_state (int): Random seed for reproducibility
    
    Returns:
    tuple: (model, X_train, X_test, y_train, y_test) - trained model and data splits
    """
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    
    # Apply SMOTE to handle class imbalance
    smote = SMOTE(random_state=random_state)
    X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)
    
    # Initialize and train the Random Forest model
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=random_state,
        n_jobs=-1
    )
    
    model.fit(X_train_smote, y_train_smote)
    
    return model, X_train, X_test, y_train, y_test

def predict(model, features):
    """
    Make a breast cancer prediction using the trained model.
    
    Parameters:
    model (RandomForestClassifier): Trained Random Forest model
    features (np.array): Feature values for prediction
    
    Returns:
    tuple: (prediction, probability) - predicted class and its probability
    """
    # Make prediction
    prediction = model.predict(features)[0]
    
    # Get probability of the positive class (malignant)
    probability = model.predict_proba(features)[0][1]
    
    return prediction, probability

def get_model_performance(model, X_test, y_test, feature_names):
    """
    Calculate and return model performance metrics.
    
    Parameters:
    model (RandomForestClassifier): Trained Random Forest model
    X_test (np.array): Test features
    y_test (np.array): Test target
    feature_names (list): Names of the features
    
    Returns:
    tuple: (metrics_dict, conf_matrix, feature_importance) - performance metrics
    """
    # Make predictions
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    
    # Calculate metrics
    metrics = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1': f1_score(y_test, y_pred),
        'roc_auc': roc_auc_score(y_test, y_prob)
    }
    
    # Confusion matrix
    conf_matrix = confusion_matrix(y_test, y_pred)
    
    # Feature importance
    feature_importance = model.feature_importances_
    
    return metrics, conf_matrix, feature_importance
