import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from utils import load_data, preprocess_data, create_feature_input
from model import train_model, predict, get_model_performance
from breast_cancer_awareness import show_awareness_page
from model_performance_page import show_model_performance_page

# Set page config
st.set_page_config(
    page_title="Breast Cancer Prediction Dashboard",
    page_icon="🎀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Add custom CSS for styling
st.markdown("""
<style>
.metric-card {
    background-color: #FFEEF6;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    border: 1px solid #FF69B4;
}
.pink-header {
    color: #FF69B4;
}
.stTabs [data-baseweb="tab-list"] {
    gap: 2px;
}
.stTabs [data-baseweb="tab"] {
    background-color: #FFEEF6;
    border-radius: 4px 4px 0px 0px;
    padding: 10px 20px;
    border: 1px solid #FF69B4;
}
.stTabs [aria-selected="true"] {
    background-color: #FF69B4;
    color: white;
}
</style>
""", unsafe_allow_html=True)

# Load the data
@st.cache_data
def get_data():
    return load_data("attached_assets/breast-cancer.csv")

data = get_data()

# Sidebar navigation with custom styling
st.sidebar.markdown("<h2 style='text-align: center; color: #FF69B4;'>Navigation</h2>", unsafe_allow_html=True)

# Add breast cancer ribbon image to sidebar
st.sidebar.image("assets/pink_ribbon.svg", width=100)

selected_page = st.sidebar.radio(
    "Go to",
    ["Home", "Dataset Overview", "Exploratory Analysis", "Feature Correlation", 
     "Prediction Interface", "Model Performance", "Breast Cancer Awareness"]
)

# Home page
if selected_page == "Home":
    st.title("Breast Cancer Prediction Dashboard")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.image('assets/pink_ribbon.svg', width=200)
        
    with col2:
        st.subheader("About this Dashboard")
        st.markdown("""
        This dashboard provides tools to explore and analyze breast cancer data and make predictions using a machine learning model.

        **Dataset**: The Wisconsin Breast Cancer dataset includes features computed from digitized images of fine needle aspirates (FNA) of breast masses. 
        The features describe characteristics of the cell nuclei present in the images.

        **Features**: Each record represents measurements for cell nuclei, including properties like:
        - **Radius** (mean distance from center to perimeter)
        - **Texture** (standard deviation of gray-scale values)
        - **Perimeter** and **Area**
        - **Smoothness** (local variation in radius lengths)
        - **Compactness** (perimeter² / area - 1.0)
        - **Concavity** (severity of concave portions of the contour)
        - And more...
        
        **Diagnosis**: 'M' indicates Malignant (cancerous), 'B' indicates Benign (non-cancerous)
        """)
    
    st.subheader("Dashboard Sections")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **Dataset Overview**: 
        - View the raw data
        - Data statistics and summary
        - Check data distribution
        """)
        
    with col2:
        st.markdown("""
        **Exploratory Analysis**:
        - Interactive feature visualizations
        - Feature comparisons
        - Distribution analysis by diagnosis
        """)
        
    with col3:
        st.markdown("""
        **Prediction**:
        - Input feature values
        - Get breast cancer prediction
        - View model performance metrics
        """)

# Dataset Overview page
elif selected_page == "Dataset Overview":
    st.title("Dataset Overview")
    
    tab1, tab2, tab3 = st.tabs(["Data Preview", "Statistics", "Class Distribution"])
    
    with tab1:
        st.subheader("Breast Cancer Data")
        st.dataframe(data, use_container_width=True)
        
        # Data shape
        st.info(f"Dataset Shape: {data.shape[0]} rows and {data.shape[1]} columns")
        
        # Check for missing values
        missing_data = data.isnull().sum().sum()
        if missing_data > 0:
            st.warning(f"Missing values found: {missing_data}")
        else:
            st.success("No missing values in the dataset!")
    
    with tab2:
        # Display descriptive statistics
        st.subheader("Descriptive Statistics")
        
        numeric_cols = data.select_dtypes(include=['float64', 'int64']).columns
        desc_stats = data[numeric_cols].describe().T.reset_index()
        desc_stats = desc_stats.rename(columns={'index': 'Feature'})
        
        st.dataframe(desc_stats.round(2), use_container_width=True)
        
        # Feature selection for statistics visualization
        selected_feature = st.selectbox(
            "Select a feature to visualize its statistics",
            options=numeric_cols
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Box plot for the selected feature by diagnosis
            fig = px.box(data, x='diagnosis', y=selected_feature, 
                        color='diagnosis', 
                        color_discrete_map={'M': '#FF4B4B', 'B': '#2E86C1'},
                        title=f"Box Plot: {selected_feature} by Diagnosis")
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Histogram for the selected feature
            fig = px.histogram(data, x=selected_feature, color='diagnosis',
                            color_discrete_map={'M': '#FF4B4B', 'B': '#2E86C1'},
                            marginal="box",
                            title=f"Histogram: {selected_feature} Distribution")
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.subheader("Class Distribution")
        
        # Count of diagnosis (M/B)
        diagnosis_count = data['diagnosis'].value_counts().reset_index()
        diagnosis_count.columns = ['Diagnosis', 'Count']
        diagnosis_count['Percentage'] = round(100 * diagnosis_count['Count'] / diagnosis_count['Count'].sum(), 2)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.dataframe(diagnosis_count, use_container_width=True)
            
            # Add descriptive text
            if 'M' in diagnosis_count['Diagnosis'].values and 'B' in diagnosis_count['Diagnosis'].values:
                m_count = diagnosis_count[diagnosis_count['Diagnosis'] == 'M']['Count'].iloc[0]
                b_count = diagnosis_count[diagnosis_count['Diagnosis'] == 'B']['Count'].iloc[0]
                m_pct = diagnosis_count[diagnosis_count['Diagnosis'] == 'M']['Percentage'].iloc[0]
                b_pct = diagnosis_count[diagnosis_count['Diagnosis'] == 'B']['Percentage'].iloc[0]
                
                st.info(f"""
                - **Malignant (M)**: {m_count} samples ({m_pct}%)
                - **Benign (B)**: {b_count} samples ({b_pct}%)
                """)
        
        with col2:
            # Pie chart for diagnosis distribution
            fig = px.pie(diagnosis_count, values='Count', names='Diagnosis',
                        color='Diagnosis',
                        color_discrete_map={'M': '#FF69B4', 'B': '#2E86C1'},
                        title="Diagnosis Distribution")
            fig.update_traces(textposition='inside', textinfo='percent+label')
            st.plotly_chart(fig, use_container_width=True)

# Exploratory Analysis page
elif selected_page == "Exploratory Analysis":
    st.title("Exploratory Data Analysis")
    
    # Filter out 'id' column and select feature types
    feature_cols = [col for col in data.columns if col not in ['id', 'diagnosis']]
    
    # Organize features by type
    mean_features = [col for col in feature_cols if '_mean' in col]
    se_features = [col for col in feature_cols if '_se' in col]
    worst_features = [col for col in feature_cols if '_worst' in col]
    
    # Create tabs for different feature groups
    tab1, tab2, tab3, tab4 = st.tabs(["Feature Exploration", "Mean Features", "SE Features", "Worst Features"])
    
    with tab1:
        st.subheader("Interactive Feature Exploration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            x_feature = st.selectbox("Select X-axis feature", feature_cols, index=0)
        
        with col2:
            y_feature = st.selectbox("Select Y-axis feature", feature_cols, index=2)
        
        # Create a scatter plot
        fig = px.scatter(data, x=x_feature, y=y_feature, color='diagnosis',
                        color_discrete_map={'M': '#FF69B4', 'B': '#2E86C1'},
                        hover_data=['id'],
                        title=f"{x_feature} vs {y_feature} by Diagnosis")
        st.plotly_chart(fig, use_container_width=True)
        
        # Add trend lines option
        if st.checkbox("Add trend lines"):
            fig = px.scatter(data, x=x_feature, y=y_feature, color='diagnosis',
                            color_discrete_map={'M': '#FF69B4', 'B': '#2E86C1'},
                            trendline="ols",
                            title=f"{x_feature} vs {y_feature} by Diagnosis with Trend Lines")
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("Mean Features Analysis")
        
        # Create a 3D scatter plot for mean features
        col1, col2, col3 = st.columns(3)
        
        with col1:
            x_mean = st.selectbox("Select X-axis mean feature", mean_features, index=0)
        
        with col2:
            y_mean = st.selectbox("Select Y-axis mean feature", mean_features, index=1)
        
        with col3:
            z_mean = st.selectbox("Select Z-axis mean feature", mean_features, index=2)
        
        # Create 3D scatter plot
        fig = px.scatter_3d(data, x=x_mean, y=y_mean, z=z_mean,
                            color='diagnosis',
                            color_discrete_map={'M': '#FF69B4', 'B': '#2E86C1'},
                            title=f"3D Plot: {x_mean}, {y_mean}, {z_mean} by Diagnosis")
        
        fig.update_layout(scene=dict(
            xaxis_title=x_mean,
            yaxis_title=y_mean,
            zaxis_title=z_mean),
            margin=dict(r=0, b=0, l=0, t=40)
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.subheader("Standard Error Features Analysis")
        
        # Display parallel coordinates for SE features
        if st.checkbox("Show parallel coordinates for SE features"):
            # Create a numeric version of diagnosis for color
            data_temp = data.copy()
            data_temp['diagnosis_numeric'] = data_temp['diagnosis'].apply(lambda x: 1 if x == 'M' else 0)
            
            fig = px.parallel_coordinates(data_temp, color="diagnosis_numeric",
                                        dimensions=se_features,
                                        color_continuous_scale=px.colors.diverging.Tealrose,
                                        title="Parallel Coordinates: Standard Error Features")
            st.plotly_chart(fig, use_container_width=True)
        
        # Display radar chart for selected samples
        if st.checkbox("Show radar chart for selected samples"):
            sample_ids = st.multiselect(
                "Select sample IDs to compare",
                options=data['id'].unique(),
                default=data['id'].unique()[:3]
            )
            
            if sample_ids:
                # Create radar chart
                selected_samples = data[data['id'].isin(sample_ids)]
                fig = go.Figure()
                
                for i, row in selected_samples.iterrows():
                    fig.add_trace(go.Scatterpolar(
                        r=[row[feat] for feat in se_features],
                        theta=se_features,
                        fill='toself',
                        name=f"ID: {row['id']} ({row['diagnosis']})"
                    ))
                
                fig.update_layout(
                    polar=dict(
                        radialaxis=dict(
                            visible=True,
                        )),
                    showlegend=True,
                    title="Radar Chart: SE Features Comparison"
                )
                
                st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        st.subheader("Worst Features Analysis")
        
        # Display violin plots for worst features
        selected_worst_feature = st.selectbox(
            "Select a worst feature to analyze",
            options=worst_features
        )
        
        fig = px.violin(data, y=selected_worst_feature, x="diagnosis", color="diagnosis",
                      box=True, points="all",
                      color_discrete_map={'M': '#FF69B4', 'B': '#2E86C1'},
                      title=f"Violin Plot: {selected_worst_feature} by Diagnosis")
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Add descriptive statistics
        st.write("Descriptive Statistics by Diagnosis:")
        
        stats_by_diagnosis = data.groupby('diagnosis')[selected_worst_feature].describe().reset_index()
        st.dataframe(stats_by_diagnosis, use_container_width=True)

# Feature Correlation page
elif selected_page == "Feature Correlation":
    st.title("Feature Correlation Analysis")
    
    # Filter out 'id' column and select only numeric columns
    numeric_cols = data.select_dtypes(include=['float64', 'int64']).columns.tolist()
    
    tab1, tab2 = st.tabs(["Correlation Matrix", "Pairwise Correlations"])
    
    with tab1:
        st.subheader("Feature Correlation Matrix")
        
        # Feature type selection
        feature_type = st.radio(
            "Select feature type",
            ["All Features", "Mean Features", "SE Features", "Worst Features"]
        )
        
        # Filter features based on selection
        if feature_type == "Mean Features":
            selected_features = [col for col in numeric_cols if '_mean' in col]
        elif feature_type == "SE Features":
            selected_features = [col for col in numeric_cols if '_se' in col]
        elif feature_type == "Worst Features":
            selected_features = [col for col in numeric_cols if '_worst' in col]
        else:
            selected_features = numeric_cols
        
        # Compute correlation matrix
        corr_matrix = data[selected_features].corr()
        
        # Create heatmap
        fig, ax = plt.subplots(figsize=(10, 8))
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        cmap = sns.diverging_palette(230, 20, as_cmap=True)
        
        sns.heatmap(corr_matrix, mask=mask, cmap=cmap, vmax=1, vmin=-1, center=0,
                   square=True, linewidths=.5, annot=False, fmt='.2f', ax=ax)
        
        plt.title(f"Correlation Matrix for {feature_type}")
        st.pyplot(fig)
        
        # Feature correlation with diagnosis
        if st.checkbox("Show correlation with diagnosis"):
            # Convert diagnosis to numeric (M=1, B=0)
            data_temp = data.copy()
            data_temp['diagnosis_numeric'] = data_temp['diagnosis'].apply(lambda x: 1 if x == 'M' else 0)
            
            # Calculate correlation with diagnosis
            corr_with_diagnosis = data_temp[selected_features + ['diagnosis_numeric']].corr()['diagnosis_numeric'].drop('diagnosis_numeric').sort_values(ascending=False)
            
            # Display as bar chart
            fig = px.bar(
                x=corr_with_diagnosis.index,
                y=corr_with_diagnosis.values,
                labels={'x': 'Feature', 'y': 'Correlation with Diagnosis'},
                title="Feature Correlation with Diagnosis",
                color=corr_with_diagnosis.values,
                color_continuous_scale=px.colors.sequential.RdBu
            )
            
            fig.update_layout(xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("Pairwise Feature Correlations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            feature1 = st.selectbox("Select first feature", numeric_cols, index=0)
        
        with col2:
            feature2 = st.selectbox("Select second feature", numeric_cols, index=1)
        
        # Create scatter plot with trend line
        fig = px.scatter(data, x=feature1, y=feature2, color='diagnosis',
                        color_discrete_map={'M': '#FF69B4', 'B': '#2E86C1'},
                        trendline="ols",
                        title=f"Correlation between {feature1} and {feature2}")
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Calculate correlation coefficient
        correlation = data[[feature1, feature2]].corr().iloc[0, 1]
        
        # Display correlation coefficient
        st.info(f"Correlation coefficient: {correlation:.4f}")
        
        # Interpret correlation strength
        if abs(correlation) > 0.7:
            strength = "Strong"
        elif abs(correlation) > 0.4:
            strength = "Moderate"
        else:
            strength = "Weak"
            
        direction = "positive" if correlation > 0 else "negative"
        
        st.write(f"These features have a **{strength} {direction}** correlation.")

# Prediction Interface page
elif selected_page == "Prediction Interface":
    st.title("Breast Cancer Prediction")
    
    # Prepare data for model
    X, y, feature_names = preprocess_data(data)
    
    # Train the model
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    st.header("Input Features for Prediction")
    
    tab1, tab2 = st.tabs(["Manual Input", "Sample Selection"])
    
    with tab1:
        st.subheader("Enter Feature Values Manually")
        
        st.markdown("""
        Enter values for the features below to get a breast cancer prediction.
        The values should be within the range specified for each feature.
        """)
        
        # Create a message about using mean features only for better user experience
        st.info("For a simplified prediction interface, we're using only the mean features. The model has been retrained to work with these features.")
        
        # Create columns for input features
        col1, col2, col3 = st.columns(3)
        
        # Identify mean features only
        mean_features = [f for f in feature_names if '_mean' in f]
        
        # Create input fields for mean features only
        input_features = {}
        
        with col1:
            st.markdown("**Cell Size Features**")
            input_features.update(create_feature_input(data, ['radius_mean', 'perimeter_mean', 'area_mean']))
        
        with col2:
            st.markdown("**Cell Shape Features**")
            input_features.update(create_feature_input(data, ['texture_mean', 'smoothness_mean', 'compactness_mean']))
        
        with col3:
            st.markdown("**Cell Characteristic Features**")
            input_features.update(create_feature_input(data, ['concavity_mean', 'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean']))
        
        # Train a model using only mean features for prediction
        X_mean = X[:, [feature_names.index(feat) for feat in mean_features]]
        mean_model, _, _, _, _ = train_model(X_mean, y)
        
        # Create input array in correct order
        input_array = np.array([input_features[f] for f in mean_features]).reshape(1, -1)
        
        # Make prediction when button is clicked
        if st.button("Predict", key="manual_predict"):
            # Get prediction and probability
            prediction, probability = predict(mean_model, input_array)
            
            # Display prediction result
            st.subheader("Prediction Result")
            
            col1, col2 = st.columns(2)
            
            with col1:
                if prediction == 1:
                    st.error("Prediction: **Malignant (M)**")
                    st.write(f"Confidence: {probability:.2%}")
                else:
                    st.success("Prediction: **Benign (B)**")
                    st.write(f"Confidence: {probability:.2%}")
            
            with col2:
                # Create gauge chart for probability
                fig = go.Figure(go.Indicator(
                    mode = "gauge+number",
                    value = probability * 100,
                    title = {'text': "Malignancy Probability"},
                    gauge = {
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "darkred" if prediction == 1 else "darkgreen"},
                        'steps': [
                            {'range': [0, 50], 'color': "lightgreen"},
                            {'range': [50, 100], 'color': "lightcoral"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 50
                        }
                    }
                ))
                
                st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("Select a Sample from the Dataset")
        
        # Allow users to select a sample from the dataset
        selected_id = st.selectbox(
            "Select a sample ID",
            options=data['id'].tolist()
        )
        
        # Display the selected sample
        selected_sample = data[data['id'] == selected_id]
        st.dataframe(selected_sample, use_container_width=True)
        
        # Get actual diagnosis
        actual_diagnosis = selected_sample['diagnosis'].iloc[0]
        
        # Extract mean features for prediction
        sample_features = {}
        for feature in mean_features:
            sample_features[feature] = float(selected_sample[feature].iloc[0])
        
        # Create input array for the selected sample in correct order
        sample_array = np.array([sample_features[f] for f in mean_features]).reshape(1, -1)
        
        # Make prediction when button is clicked
        if st.button("Predict", key="sample_predict"):
            # Get prediction and probability
            prediction, probability = predict(mean_model, sample_array)
            
            # Display prediction result
            st.subheader("Prediction Result")
            
            col1, col2 = st.columns(2)
            
            with col1:
                if prediction == 1:
                    st.error("Prediction: **Malignant (M)**")
                else:
                    st.success("Prediction: **Benign (B)**")
                
                st.write(f"Actual Diagnosis: **{actual_diagnosis}**")
                
                # Check if prediction matches actual diagnosis
                predicted_diagnosis = 'M' if prediction == 1 else 'B'
                if predicted_diagnosis == actual_diagnosis:
                    st.success("✓ Correct prediction!")
                else:
                    st.error("✗ Incorrect prediction!")
            
            with col2:
                # Create gauge chart for probability
                fig = go.Figure(go.Indicator(
                    mode = "gauge+number",
                    value = probability * 100,
                    title = {'text': "Malignancy Probability"},
                    gauge = {
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "darkred" if prediction == 1 else "darkgreen"},
                        'steps': [
                            {'range': [0, 50], 'color': "lightgreen"},
                            {'range': [50, 100], 'color': "lightcoral"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 50
                        }
                    }
                ))
                
                st.plotly_chart(fig, use_container_width=True)

# Model Performance page
elif selected_page == "Model Performance":
    st.title("Model Performance and Insights")
    st.markdown("<p style='color: #FF69B4;'>Understanding how our model predicts breast cancer cases</p>", unsafe_allow_html=True)
    
    # Prepare data for model
    X, y, feature_names = preprocess_data(data)
    
    # Train the model
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    # Show model performance using our custom page
    show_model_performance_page(model, X_test, y_test, feature_names)
    
# Breast Cancer Awareness page
elif selected_page == "Breast Cancer Awareness":
    show_awareness_page()